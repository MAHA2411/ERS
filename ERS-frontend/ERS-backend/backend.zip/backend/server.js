// server.js
import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors";

// Routes
import authRoutes from "./routes/authRoutes.js";             // User auth (register, login, forgot/reset)
import eventRoutes from "./routes/eventRoutes.js";           // Public event browsing
import registerEventRoutes from "./routes/registerEventRoutes.js"; // Event registration (users)
import adminRoutes from "./routes/adminRoutes.js";           // Admin + SuperAdmin (events & registrations)
import adminUserRoutes from "./routes/adminUserRoutes.js";   // SuperAdmin managing Admin accounts

dotenv.config();

const app = express();

// Middlewares
app.use(express.json());
app.use(cors({ origin: "http://localhost:3000", credentials: true }));

// Routes mounting
app.use("/api/auth", authRoutes);              // Normal user login/register
app.use("/api/events", eventRoutes);           // Public events
app.use("/api", registerEventRoutes);          // User event registration
app.use("/api/admin", adminRoutes);            // Admin + SuperAdmin login, events, registrations
app.use("/api/admin/users", adminUserRoutes);  // SuperAdmin manage Admins

// Server + DB connection
const PORT = process.env.PORT || 5000;

mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("✅ MongoDB connected");
    app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
  })
  .catch((err) => console.error("❌ DB connection error:", err));
