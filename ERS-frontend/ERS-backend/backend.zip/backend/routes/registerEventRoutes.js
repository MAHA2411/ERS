// ERS-backend/routes/registerEventRoutes.js
import express from "express";
import { registerEvent, getMyRegisteredEvents } from "../controllers/registerEventController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/register-event", protect, registerEvent);
router.get("/register-event/mine", protect, getMyRegisteredEvents);

export default router;
