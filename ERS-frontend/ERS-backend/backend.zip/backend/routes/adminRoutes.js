// ERS-backend/routes/adminRoutes.js
import express from "express";
import { loginAdminOrSuperAdmin } from "../controllers/adminAuthController.js";
import {
  listEvents,
  createEvent,
  updateEvent,
  deleteEvent,
  listRegistrations,
} from "../controllers/adminController.js";
import {
  protect,
  verifyAdminOrSuperAdmin,
} from "../middleware/authMiddleware.js";

const router = express.Router();
// Admin & SuperAdmin login
router.post("/login", loginAdminOrSuperAdmin);

// Events
router.get("/events", protect, verifyAdminOrSuperAdmin, listEvents);
router.post("/events", protect, verifyAdminOrSuperAdmin, createEvent);
router.put("/events/:id", protect, verifyAdminOrSuperAdmin, updateEvent);
router.delete("/events/:id", protect, verifyAdminOrSuperAdmin, deleteEvent);

// Registrations
router.get(
  "/registrations",
  protect,
  verifyAdminOrSuperAdmin,
  listRegistrations
);

export default router;
