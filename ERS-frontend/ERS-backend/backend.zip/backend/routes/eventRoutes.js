import express from "express";
import { protect } from "../middleware/authMiddleware.js";
import { createEvent, editEvent, getEvents, getRegistrations } from "../controllers/eventController.js";

const router = express.Router();
router.get("/:eventId/is-registered", protect, async (req, res) => {
  try {
    const exists = await Registration.findOne({
      eventId: req.params.eventId,
      userId: req.user._id
    });
    res.json({ registered: !!exists });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post("/", protect, createEvent); // Both Admin & SuperAdmin can create
router.put("/:id", protect, editEvent);
router.get("/", protect, getEvents);
router.get("/registrations", protect, getRegistrations);

export default router;
