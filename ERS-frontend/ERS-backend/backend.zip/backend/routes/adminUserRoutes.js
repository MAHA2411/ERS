import express from "express";
import {
  getAdmins,
  addAdmin,
  updateAdmin,
  deleteAdmin,
} from "../controllers/adminUserController.js";
import { protect, verifySuperAdmin } from "../middleware/authMiddleware.js";

const router = express.Router();

// Only SuperAdmin should manage Admins
router.get("/", protect, verifySuperAdmin, getAdmins);
router.post("/", protect, verifySuperAdmin, addAdmin);
router.put("/:id", protect, verifySuperAdmin, updateAdmin);
router.delete("/:id", protect, verifySuperAdmin, deleteAdmin);

export default router;
