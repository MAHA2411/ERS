import express from "express";
import {
  registerUser,
  loginUser,
  loginAdmin,
  loginSuperAdmin,
  forgotPassword,
  resetPassword,
} from "../controllers/authController.js";

const router = express.Router();

//
// ===== USER AUTH =====
//

// Register new user
router.post("/register", registerUser);

// Login user
router.post("/login", loginUser);

// Forgot password (send reset link to email)
router.post("/forgot-password", forgotPassword);

// Reset password (via link in email)
router.post("/reset-password/:token", resetPassword);

//
// ===== ADMIN AUTH =====
//

// Login Admin
router.post("/admin/login", loginAdmin);

//
// ===== SUPERADMIN AUTH =====
//

// Login SuperAdmin
router.post("/superadmin/login", loginSuperAdmin);

export default router;
