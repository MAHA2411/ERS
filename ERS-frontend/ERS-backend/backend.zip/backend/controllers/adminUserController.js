// ERS-backend/controllers/adminUserController.js
import Admin from "../models/Admin.js";
import bcrypt from "bcryptjs";

// View all admins
export const getAdmins = async (req, res) => {
  try {
    const admins = await Admin.find().select("-password"); // only Admins collection
    res.json(admins);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Add new admin
export const addAdmin = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ message: "All fields required" });
    }

    const exists = await Admin.findOne({ email });
    if (exists) {
      return res.status(400).json({ message: "Admin already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const admin = await Admin.create({ name, email, password: hashedPassword });

    res.status(201).json(admin);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Edit admin
export const updateAdmin = async (req, res) => {
  try {
    const { password, ...rest } = req.body;
    let updateData = rest;

    if (password) {
      updateData.password = await bcrypt.hash(password, 10);
    }

    const admin = await Admin.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true }
    ).select("-password");

    if (!admin) return res.status(404).json({ message: "Admin not found" });
    res.json(admin);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Delete admin
export const deleteAdmin = async (req, res) => {
  try {
    const admin = await Admin.findByIdAndDelete(req.params.id);
    if (!admin) return res.status(404).json({ message: "Admin not found" });

    res.json({ message: "Admin removed successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
