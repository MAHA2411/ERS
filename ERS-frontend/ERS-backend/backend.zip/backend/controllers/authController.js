// ERS-backend/controllers/authController.js
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import User from "../models/User.js";
import Admin from "../models/Admin.js";
import SuperAdmin from "../models/SuperAdmin.js";
import sendEmail from "../utils/sendEmail.js"; // nodemailer utility

// 🔹 Helper to generate JWT
const generateToken = (id, role, rememberMe) => {
  const tokenExpiry = rememberMe ? "30d" : "1d";
  return jwt.sign({ id, role }, process.env.JWT_SECRET, { expiresIn: tokenExpiry });
};

//
// ================== USER CONTROLLERS ==================
//

// Register new User
export const registerUser = async (req, res) => {
  try {
    let { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ message: "All fields are required" });
    }

    email = email.trim().toLowerCase();
    const exists = await User.findOne({ email });
    if (exists) return res.status(400).json({ message: "User already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);
    await User.create({ name, email, password: hashedPassword });

    res.status(201).json({ message: "User registered successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Login User
export const loginUser = async (req, res) => {
  try {
    let { email, password, rememberMe } = req.body;
    if (!email || !password) return res.status(400).json({ message: "Email and password required" });

    email = email.trim().toLowerCase();
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: "Invalid credentials" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: "Invalid credentials" });

    const token = generateToken(user._id, "User", rememberMe);
    res.json({ token, user: { id: user._id, name: user.name, email: user.email, role: "User" } });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

//
// ================== ADMIN CONTROLLERS ==================
//

// Login Admin
export const loginAdmin = async (req, res) => {
  try {
    let { email, password, rememberMe } = req.body;
    if (!email || !password) return res.status(400).json({ message: "Email and password required" });

    email = email.trim().toLowerCase();
    const admin = await Admin.findOne({ email });
    if (!admin) return res.status(400).json({ message: "Invalid credentials" });

    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch) return res.status(400).json({ message: "Invalid credentials" });

    const token = generateToken(admin._id, "Admin", rememberMe);
    res.json({ token, admin: { id: admin._id, name: admin.name, email: admin.email, role: "Admin" } });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

//
// ================== SUPERADMIN CONTROLLERS ==================
//

// Login SuperAdmin
export const loginSuperAdmin = async (req, res) => {
  try {
    let { email, password, rememberMe } = req.body;
    if (!email || !password) return res.status(400).json({ message: "Email and password required" });

    email = email.trim().toLowerCase();
    const superAdmin = await SuperAdmin.findOne({ email });
    if (!superAdmin) return res.status(400).json({ message: "Invalid credentials" });

    const isMatch = await bcrypt.compare(password, superAdmin.password);
    if (!isMatch) return res.status(400).json({ message: "Invalid credentials" });

    const token = generateToken(superAdmin._id, "SuperAdmin", rememberMe);
    res.json({ token, superAdmin: { id: superAdmin._id, name: superAdmin.name, email: superAdmin.email, role: "SuperAdmin" } });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

//
// ================== PASSWORD RESET (Users Only for now) ==================
//

// Forgot Password
export const forgotPassword = async (req, res) => {
  try {
    let { email } = req.body;
    if (!email) return res.status(400).json({ message: "Email is required" });

    email = email.trim().toLowerCase();
    const user = await User.findOne({ email });

    if (user) {
      const resetToken = crypto.randomBytes(32).toString("hex");
      const resetTokenHash = crypto.createHash("sha256").update(resetToken).digest("hex");

      user.resetPasswordToken = resetTokenHash;
      user.resetPasswordExpire = Date.now() + 15 * 60 * 1000;
      await user.save();

      const resetUrl = `${process.env.FRONTEND_URL}/reset-password/${resetToken}`;

      await sendEmail(
        user.email,
        "Password Reset Request",
        `<p>You requested a password reset.</p>
         <p>Click below (valid 15 min):</p>
         <p><a href="${resetUrl}" target="_blank">${resetUrl}</a></p>`
      );
    }

    res.json({ message: "If that email exists, a reset link has been sent." });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Reset Password
export const resetPassword = async (req, res) => {
  try {
    const { token } = req.params;
    const { password } = req.body;
    if (!password) return res.status(400).json({ message: "Password is required" });

    const resetTokenHash = crypto.createHash("sha256").update(token).digest("hex");
    const user = await User.findOne({
      resetPasswordToken: resetTokenHash,
      resetPasswordExpire: { $gt: Date.now() },
    });

    if (!user) return res.status(400).json({ message: "Invalid or expired token" });

    user.password = await bcrypt.hash(password, 10);
    user.resetPasswordToken = undefined;
    user.resetPasswordExpire = undefined;
    await user.save();

    res.json({ message: "Password reset successful" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

