import Event from "../models/Event.js";
import Registration from "../models/Registration.js";

// Create Event (Admin or SuperAdmin)
export const createEvent = async (req, res) => {
  try {
    const event = await Event.create({
      ...req.body,
      createdBy: req.user._id // Store who created it
    });
    res.status(201).json(event);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Edit Event
export const editEvent = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);

    if (!event) return res.status(404).json({ message: "Event not found" });

    // Admin can only edit their own event
    if (req.user.role !== "SuperAdmin" && event.createdBy.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized" });
    }

    Object.assign(event, req.body);
    await event.save();

    res.json({ message: "Event updated", event });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get Events (filter based on role)
export const getEvents = async (req, res) => {
  try {
    let events;
    if (req.user.role === "SuperAdmin") {
      events = await Event.find();
    } else {
      events = await Event.find({ createdBy: req.user._id });
    }
    res.json(events);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get Registrations (filtered)
export const getRegistrations = async (req, res) => {
  try {
    let registrations;
    if (req.user.role === "SuperAdmin") {
      registrations = await Registration.find().populate("event");
    } else {
      registrations = await Registration.find()
        .populate("event")
        .then(regs => regs.filter(r => r.event.createdBy.toString() === req.user._id.toString()));
    }
    res.json(registrations);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
