// ERS-backend/controllers/registerEventController.js
import mongoose from "mongoose";
import PDFDocument from "pdfkit";
import streamBuffers from "stream-buffers";

import Registration from "../models/Registration.js";
import Event from "../models/Event.js";
import sendEmail from "../utils/sendEmail.js";

/**
 * POST /api/register-event
 * Requires auth (protect middleware). Expects body: { eventId, name, email, phone?, college?, department?, year? }
 * Saves registration with user = req.user._id and emails a PDF ticket.
 */
export const registerEvent = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    // make sure protect middleware set req.user
    if (!req.user || !req.user._id) {
      await session.abortTransaction();
      session.endSession();
      return res.status(401).json({ message: "Unauthorized" });
    }

    const { eventId, name, email, phone, college, department, year } = req.body;

    if (!eventId || !name || !email) {
      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({ message: "Missing fields" });
    }

    const ev = await Event.findById(eventId).session(session);
    if (!ev) {
      await session.abortTransaction();
      session.endSession();
      return res.status(404).json({ message: "Event not found" });
    }

    const ticketId = `TICKET-${Date.now().toString(36).toUpperCase().slice(-8)}`;

    // Build the PDF ticket in memory
    const doc = new PDFDocument({ size: "A4", margin: 50 });
    const writableStreamBuffer = new streamBuffers.WritableStreamBuffer({
      initialSize: 100 * 1024,
      incrementAmount: 10 * 1024,
    });

    doc.fontSize(20).text("EventHub - E-Ticket", { align: "center" });
    doc.moveDown();
    doc.fontSize(16).text(`Event: ${ev.title}`);
    doc.text(`Date: ${ev.date ? new Date(ev.date).toDateString() : "TBA"}`);
    doc.text(`Venue: ${ev.venue || "TBA"}`);
    doc.moveDown();
    doc.text(`Attendee: ${name}`);
    doc.text(`Email: ${email}`);
    doc.text(`Phone: ${phone || "-"}`);
    doc.moveDown();
    doc.text(`Ticket ID: ${ticketId}`, { underline: true });

    doc.pipe(writableStreamBuffer);
    doc.end();

    // Wait for PDF to finish
    await new Promise((resolve) => doc.on("end", resolve));
    const pdfBuffer = writableStreamBuffer.getContents();

    // Email the PDF ticket
    await sendEmail(
      email,
      `Registration Confirmation - ${ev.title}`,
      `<p>Hi ${name},</p>
       <p>Thanks for registering for <strong>${ev.title}</strong>.</p>
       <p>Your Ticket ID: <strong>${ticketId}</strong></p>
       <p>Please bring this ticket with you to the event.</p>
       <p>Thanks,<br/>Event Team</p>`,
      [
        {
          filename: `Ticket-${ticketId}.pdf`,
          content: pdfBuffer,
        },
      ]
    );

    // Save the registration (IMPORTANT: tie to user)
    const [reg] = await Registration.create(
      [
        {
          user: req.user._id, // <-- required for /mine
          eventId,
          name,
          email,
          phone,
          college,
          department,
          year,
          ticketId,
        },
      ],
      { session }
    );

    await session.commitTransaction();
    session.endSession();

    return res.status(201).json({
      message: "Registered successfully",
      registrationId: reg._id,
      ticketId,
    });
  } catch (err) {
    console.error("Registration error:", err);
    await session.abortTransaction();
    session.endSession();
    return res.status(500).json({ message: "Registration failed" });
  }
};

/**
 * GET /api/register-event/mine
 * Requires auth (protect). Returns all registrations (with populated event) for the logged-in user.
 */
export const getMyRegisteredEvents = async (req, res) => {
  try {
    if (!req.user || !req.user._id) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const registrations = await Registration.find({ user: req.user._id })
      .populate("eventId", "title date venue fee"); // pick fields you need

    // If your frontend only needs event IDs, you could map here instead:
    // const eventIds = registrations.map(r => r.eventId?._id).filter(Boolean);
    // return res.json(eventIds);

    return res.json(registrations);
  } catch (error) {
    console.error("Error fetching registered events:", error);
    return res.status(500).json({ message: "Failed to fetch registered events" });
  }
};
