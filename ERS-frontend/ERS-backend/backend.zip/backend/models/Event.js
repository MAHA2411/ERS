// ERS-backend/models/Event.js
import mongoose from "mongoose";

const eventSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, "Event title is required"],
      trim: true,
    },
    description: {
      type: String,
      required: [true, "Event description is required"],
    },
    date: {
      type: Date,
      required: [true, "Event date is required"],
    },
    venue: {
      type: String,
      required: [true, "Event venue is required"],
    },
    fee: {
      type: Number,
      default: 0,
    },
    bannerUrl: {
      type: String,
      required: [true, "Event banner URL is required"],
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User", // Reference to the Admin or SuperAdmin who created it
      required: true,
    },
  },
  { timestamps: true }
);

export default mongoose.model("Event", eventSchema);
