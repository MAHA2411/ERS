// ERS-backend/middleware/authMiddleware.js
import jwt from "jsonwebtoken";
import User from "../models/User.js";
import Admin from "../models/Admin.js";
import SuperAdmin from "../models/SuperAdmin.js";

export const protect = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Not authorized, no token" });
  }

  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    let user = null;

    // 🔹 Check SuperAdmin collection
    if (decoded.role === "SuperAdmin") {
      user = await SuperAdmin.findById(decoded.id).select("-password");
    }
    // 🔹 Check Admin collection
    else if (decoded.role === "Admin") {
      user = await Admin.findById(decoded.id).select("-password");
    }
    // 🔹 Check User collection
    else {
      user = await User.findById(decoded.id).select("-password");
    }

    if (!user) {
      return res.status(401).json({ message: "Not authorized, user not found" });
    }

    req.user = { ...user.toObject(), role: decoded.role }; // include role from token
    next();
  } catch (err) {
    res.status(401).json({ message: "Not authorized, token failed" });
  }
};

// ✅ Only SuperAdmin can access
export const verifySuperAdmin = (req, res, next) => {
  if (req.user.role !== "SuperAdmin") {
    return res.status(403).json({ message: "Access denied: SuperAdmin only" });
  }
  next();
};

// ✅ Both Admin & SuperAdmin can access
export const verifyAdminOrSuperAdmin = (req, res, next) => {
  if (req.user.role === "SuperAdmin" || req.user.role === "Admin") {
    return next();
  }
  return res.status(403).json({ message: "Access denied" });
};
